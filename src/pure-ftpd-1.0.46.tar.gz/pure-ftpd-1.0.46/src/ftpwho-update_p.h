#ifndef __FTPWHO_UPDATE_P_H__
#define __FTPWHO_UPDATE_P_H__ 1

static int mmap_fd = -1;
static struct flock lock;

#endif

